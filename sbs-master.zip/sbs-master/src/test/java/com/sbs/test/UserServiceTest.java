package com.sbs.test;



import static org.junit.Assert.assertEquals;

import org.junit.BeforeClass;
import org.junit.Test;

import com.sbs.exception.RecordNotFoundException;
import com.sbs.model.UserEntity;
import com.sbs.service.UserService;

import static io.restassured.RestAssured.get;
import static org.hamcrest.CoreMatchers.equalTo;

import org.junit.BeforeClass;
import org.junit.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class UserServiceTest {
	UserService service = new UserService();
	@BeforeClass
	public static void init() {
		RestAssured.baseURI = "http://localhost";
		RestAssured.port = 8080;
	}
	@Test
	public void testFetchUser() throws RecordNotFoundException {
		get("/users");
	}
}
