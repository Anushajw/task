package com.sbs.service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbs.exception.RecordNotFoundException;
import com.sbs.model.UserEntity;
import com.sbs.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	UserRepository repository;
	
	public List<UserEntity> getAllUsers(){
		List<UserEntity> userEntities = repository.findAll();
		if(userEntities.size()>0) {
			return userEntities;
		}
		else {
			return new ArrayList<UserEntity>();
		}
		
	}
	
	public UserEntity getUserById(Long id) throws RecordNotFoundException 
    {
        Optional<UserEntity> user = repository.findById(id);
         
        if(user.isPresent()) {
            return user.get();
        } else {
            throw new RecordNotFoundException("No user record exist for given id");
        }
    }
     
    public UserEntity createOrUpdateUser(UserEntity entity) throws RecordNotFoundException 
    {
        Optional<UserEntity> user = repository.findById(entity.getUserId());
         
        if(user.isPresent()) 
        {
            UserEntity newEntity = user.get();
            newEntity.setFinger(entity.getFinger());
            newEntity.setUserName(entity.getUserName());
            newEntity.setAddress(entity.getAddress());
 
            newEntity = repository.save(newEntity);
             
            return newEntity;
        } else {
            entity = repository.save(entity);
             
            return entity;
        }
    } 
     
    public void deleteUserById(Long id) throws RecordNotFoundException 
    {
        Optional<UserEntity> user = repository.findById(id);
         
        if(user.isPresent()) 
        {
            repository.deleteById(id);
        } else {
            throw new RecordNotFoundException("No user record exist for given id");
        }
    } 
}
